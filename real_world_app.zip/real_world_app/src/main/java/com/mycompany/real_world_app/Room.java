import java.util.concurrent.locks.ReentrantLock;


public class Room extends ReentrantLock {
 private int id;
 public Room(){
  
 }
 
 public Room(int id){
  this.id=id;
 }
}
