import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.ArrayList;



public class Client implements Runnable {
private int id;
 private Random timeGenerator = new Random();
 private Random RandNum = new Random();
 private Lock room [];
 private ArrayList<Integer> RoomNum = new ArrayList<Integer>(); 
 private ArrayList<Integer> BookedRoom = new ArrayList<Integer>(); 
 private ArrayList<Integer> NotBooked = new ArrayList<Integer>(); 

 public Client(){
  
 }
 
 public Client(int id , Lock room[]){
  this.room = room;
  this.id=id;
 }


 public void run(){
  try {
    while (true) {
    int x =RandNum.nextInt(5);
    for(int i = 0 ; i < x ;i++){
    RoomNum.add(RandNum.nextInt(30));
    }
    BookRoom();
    Thread.sleep(5000+timeGenerator.nextInt(1000));
    CancelBooking();
    RoomNum.clear();
    BookedRoom.clear();
    NotBooked.clear();

    }
  }catch (Exception e) {
   System.out.println("Client " + id + " Booking was interrupted.\n");   
  }
  
 }
 
 private void BookRoom() throws InterruptedException{
  
   try{
    for(int i = 0 ; i < RoomNum.size();i++){
        if(room[RoomNum.get(i)].tryLock()){
            BookedRoom.add(RoomNum.get(i));
        }
        else{
            NotBooked.add(RoomNum.get(i));
        }     
    }
   }finally{
       if(BookedRoom.size()==RoomNum.size()){
             System.out.println("Client  " + id + " booked room number" + RoomNum + ".\n");
             return;
       }
       else{
            Thread.sleep(1000);
            try{
                for(int i = 0 ; i < NotBooked.size();i++){
                    if(room[NotBooked.get(i)].tryLock()){
                        BookedRoom.add(NotBooked.get(i));
                    }
                }
            }finally{
                if(BookedRoom.size()==RoomNum.size()){
                    System.out.println("Client " + id + " booked room number" + RoomNum + ".\n");
                    return;
                }else{
                    for(int j = 0 ; j < BookedRoom.size();j++){
                         room[BookedRoom.get(j)].unlock();
                    }
                    System.out.println(id+" Booking fail     Try again after a while");
                    BookedRoom.clear();
                }
            }
        }
  }
}
  private void CancelBooking() {
      for(int j = 0 ; j < BookedRoom.size();j++){
        room[BookedRoom.get(j)].unlock();
      }
      System.out.println("room number" + BookedRoom + "is Available.\n");
}
}
 
