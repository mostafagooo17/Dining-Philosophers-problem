public class App {
 
 Room room[];
 Client client[];
 public static int NumOfClient = 5;
 public App(){
  
  initializeRoom();
  initializeClient();
  for (int i = 0; i < NumOfClient; i++) {
    new Thread(client[i]).start();
  } 
 }
 
 public void initializeRoom(){
  room =new Room[30];
  for (int i = 0; i < 30; i++) {
    room[i]=new Room(i);
  }
 }
 public void initializeClient(){
  client = new Client[NumOfClient];
  for (int i = 0; i < NumOfClient; i++) {
    client[i]=new Client(i , room);
  }
 }
 
 public static void main(String args[]){
  new App();
 }
 

}