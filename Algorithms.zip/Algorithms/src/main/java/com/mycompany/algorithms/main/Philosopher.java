import java.util.Random;
import java.util.concurrent.locks.Lock;


public class Philosopher implements Runnable {
 private int id;
 private Lock leftChopstick;
 private Lock rightChopstick;
 private Random timeGenerator = new Random();
 private Chopstick chopstick=new Chopstick();
 public Philosopher(){
  
 }
 
 public Philosopher(int id,Lock leftChopstick, Lock rightChopstick){
  this.id=id;
  this.leftChopstick=leftChopstick;
  this.rightChopstick=rightChopstick;
 }
 public void run(){
  try {
   while (true) {
    think();
    pickUpChopstick(leftChopstick,rightChopstick);
    eat();
    putDownChopsticks();
   }
  } catch (InterruptedException e) {
   System.out.println("Philosopher " + id + " was interrupted.\n");   
  }
  
 }
 
 private void think() throws InterruptedException {
  System.out.println("Philosopher " + id + " is thinking.\n");
  Thread.sleep (1000+timeGenerator.nextInt(1000));
 }
 
 private void pickUpChopstick(Lock leftChopstick,Lock rightChopstick) throws InterruptedException{
  
  while(true){
   boolean lc=false;
   boolean rc=false;
   try{
    lc=leftChopstick.tryLock();
    rc=rightChopstick.tryLock();
   }finally{
    if(lc&&rc){
     System.out.println("Philosopher " + id + " Pick Up both Chop Stick.\n");
     return;
    }
    else if(lc&&!rc){
     System.out.println("Philosopher " + id + " Pick Up  leftChop Stick And RightChop Stick is Busy.\n");
     Thread.sleep (250+timeGenerator.nextInt(200));
     rc=rightChopstick.tryLock();
     if(rc){
     System.out.println("Philosopher " + id + " Pick Up both Chop Stick.\n");
     return;
     }
     else{
     leftChopstick.unlock();
     System.out.println("Philosopher " + id + " Put Down  leftChop Stick.\n");
     }
    }
    else if(rc&&!lc){
     System.out.println("Philosopher " + id + " Pick Up  RightChop Stick And lefttChop Stick is Busy.\n");
     Thread.sleep (250+timeGenerator.nextInt(200));
     lc=leftChopstick.tryLock();
     if (lc){
     System.out.println("Philosopher " + id + " Pick Up both Chop Stick.\n");
     return;
     }
     else{
     rightChopstick.unlock();
     System.out.println("Philosopher " + id + " Put Down  RightChop Stick.\n");
     }
    }
   }
   
   try {
    Thread.sleep(1000);
   } catch (InterruptedException e) {
    e.printStackTrace();
   }
  }
  
 }
 
 private void eat() throws InterruptedException {
  Thread.sleep(50);
  System.out.println("Philosopher " + id + " is eating.\n");
  Thread.sleep (200+timeGenerator.nextInt(200)); 
 }
 
 
 private void putDownChopsticks() {
  leftChopstick.unlock();
  rightChopstick.unlock();
  System.out.println("Philosopher " + id + " put down Both ChopStick\n");
}
}