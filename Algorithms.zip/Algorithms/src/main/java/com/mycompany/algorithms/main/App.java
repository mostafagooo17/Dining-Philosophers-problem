public class App {
 
 Chopstick chopstick[];
 Philosopher philosophers[];
 public static int NumOfPhilosopher = 5;
 public App(){
  
  initializePos();
  initializePhilosopher();
  for (int i = 0; i < NumOfPhilosopher; i++) {
    new Thread(philosophers[i]).start();
  } 
 }
 
 public void initializePos(){
  chopstick=new Chopstick[NumOfPhilosopher];
  for (int i = 0; i < NumOfPhilosopher; i++) {
    chopstick[i]=new Chopstick(i);
  }
 }
 public void initializePhilosopher(){
  philosophers = new Philosopher[NumOfPhilosopher];
  for (int i = 0; i < NumOfPhilosopher; i++) {
    philosophers[i]=new Philosopher(i,chopstick[i],chopstick[(i+1)%NumOfPhilosopher]);
  }
 }
 
 public static void main(String args[]){
  new App();
 }
 

}